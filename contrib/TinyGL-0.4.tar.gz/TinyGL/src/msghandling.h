#ifndef _msghandling_h_
#define _msghandling_h_

extern void tgl_warning(const char *text, ...);
extern void tgl_trace(const char *text, ...);
extern void tgl_fixme(const char *text, ...);

#endif /* _msghandling_h_ */
